#include "start.h"
#include "ui_start.h"
#include "one.h"

start::start(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::start)
{
    ui->setupUi(this);
}

start::~start()
{
    delete ui;
}

void start::on_pushButton_clicked()
{
    one * select_background =new one;
    select_background->show();
    this->close();
}

void start::on_pushButton_2_clicked()
{
    this->close();
    exit(0);
}
