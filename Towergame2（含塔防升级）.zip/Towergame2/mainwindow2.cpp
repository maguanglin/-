#include "mainwindow2.h"
#include "ui_mainwindow2.h"
#include <QPainter>
#include "one.h"
MainWindow2::MainWindow2(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow2)
{
    ui->setupUi(this);
}

MainWindow2::~MainWindow2()
{
    delete ui;
}
void MainWindow2::paintEvent(QPaintEvent *)
{
    QPainter painter(this);
    QPixmap pix;
    pix.load(":/pic/picture/map2.jpg");
    painter.drawPixmap(0, 0, 1200, 900, pix);
}

void MainWindow2::on_pushButton_clicked()
{
    one *back =new one;
    back->show();
    this->close();
}
